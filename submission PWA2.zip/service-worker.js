const CACHE_NAME = "football data V1.1.1";
var urlsToCache = [
  "/",
  "/manifest.json",
  "/nav.html",
  "/index.html",
  "/article.html",
  "/pages/home.html",
  "/pages/saved.html",
  "/css/materialize.min.css",
  "/css/za.css",
  "/js/materialize.min.js",
  "/js/nav.js",
  "/js/register-sw.js",
  "/js/api.js",
  "/js/db.js",
  "/js/idb.js",
  "/js/snarkdown.umd.js",
  "testpush.js",
  "/asset/brand.gif",
  "/asset/brand.png",
  "/asset/delete.png",
  "/asset/football.png",
  "/asset/save.png",
  "/asset/brand1.gif",
  "/asset/brand1.png",
  "/asset/c.png",
  "/asset/cryptofun.png",
  "/asset/cryptofun512.png",
  "/asset/cryptofun192.png",
  "/asset/e.png",
  "/asset/f.png",
  "/asset/fb.png",
  "/asset/forum.png",
  "/asset/gmail.png",
  "/asset/home.png",
  "/asset/i.png",
  "/asset/insta.png",
  "/asset/load.gif",
  "/asset/news.png",
  "/asset/short.png",
  "/asset/t.png",
  "/asset/twitter.png",
];
 
self.addEventListener("install", function(event) {
  event.waitUntil(
    caches.open(CACHE_NAME).then(function(cache) {
      return cache.addAll(urlsToCache);
    })
  );
});
self.addEventListener("fetch", function(event) {
  var base_url = "https://api.football-data.org/v2/";
  if (event.request.url.indexOf(base_url) > -1) {
    event.respondWith(
      caches.open(CACHE_NAME).then(function(cache) {
        return fetch(event.request).then(function(response) {
          cache.put(event.request.url, response.clone());
          return response;
        })
      })
    );
  } else {
    event.respondWith(
        caches.match(event.request, { ignoreSearch: true }).then(function(response) {
            return response || fetch (event.request);
        })
    )
  }
});
self.addEventListener("activate", function(event) {
  event.waitUntil(
    caches.keys().then(function(cacheNames) {
      return Promise.all(
        cacheNames.map(function(cacheName) {
          if (cacheName != CACHE_NAME) {
            console.log("ServiceWorker: cache " + cacheName + " dihapus");
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});
self.addEventListener('push', function(event) {
  var body;
  if (event.data) {
    body = event.data.text();
  } else {
    body = 'Push message no payload';
  }
  var options = {
    body: body,
    icon: 'asset/brand1.png',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    }
  };
  event.waitUntil(
    self.registration.showNotification('Push Notification', options)
  );
});